Digital Slide Archive on Ubuntu 24.04 - local install package
==============================================================

Contents
--------
DSA-Ubuntu-24.04-Install-Guide.pdf   Print-ready install guide with screenshots
DSA-Ubuntu-24.04-Install-Guide.md    Markdown source
DSA-Ubuntu-24.04-Install-Guide.html  Self-contained HTML version (images embedded)
screenshots/                         Individual PNG screenshots, numbered in story order
scripts/start.sh                     Start script created in devops/ver5
transcripts/                         Raw terminal transcripts used for the terminal screenshots

Story order
-----------
01-prerequisites.png    Ubuntu, kernel, Docker, and Compose versions
02-clone-repo.png       Repository clone and checked-out commit
03-ver5-directory.png   The devops/ver5 compose stack
04-start-script.png     The start.sh script
05-pull-images.png      Pulling the container images
06-start-containers.png Compose creating and starting the containers
07-container-health.png docker compose ps and DSA version API
10-dsa-landing.png      DSA landing page at localhost:8080
11-dsa-login.png        Login dialog
12-dsa-home-admin.png   Signed-in home page
13-dsa-plugins.png      Installed plugins and DSA release
14-histomicsui.png      HistomicsUI landing page

Key facts
---------
Host: Ubuntu 24.04.5 LTS, Docker 29.9.2, Compose v5.6.1
Install path: ~/devel/digital-slide-archive
Repo commit: 2e16b9a
DSA release: 5.0.23.dev5+g70eb94dcd
URL: http://localhost:8080
Default admin login: admin / password (change it after install)

Notes
-----
- The terminal screenshots are renderings of the raw transcripts in transcripts/.
- The browser screenshots were captured from the live instance after a clean start.
- The PDF and HTML are self-contained and can be shared without the screenshots directory.
